package com.cg.learning.dao;

public interface IProductDao {
	public float getProductPrice(String pName);
}
