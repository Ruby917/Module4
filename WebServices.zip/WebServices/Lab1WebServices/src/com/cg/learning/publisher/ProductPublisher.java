package com.cg.learning.publisher;

import javax.xml.ws.Endpoint;

import com.cg.learning.beans.Product;
import com.cg.learning.webservice.ProductServiceImpl;



public class ProductPublisher {

	public static void main(String[] args) {
	      Endpoint.publish("http://127.0.0.1:9878/cs", new ProductServiceImpl());
	}

}
