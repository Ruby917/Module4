package com.cg.learning.client;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

import javax.xml.namespace.QName;
import javax.xml.ws.Service;

import com.cg.learning.webservice.IProductService;
import com.cg.learning.webservice.ProductServiceImpl;


public class Client {
	
	public static void main(String[] args) throws MalformedURLException {
		URL url = new URL("http://localhost:9878/cs?wsdl");

		QName qname = new QName("http://webservice.learning.cg.com/","ProductServiceImplService");

		Service service = Service.create(url, qname);

		IProductService endpointInterface = service.getPort(IProductService.class);

		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the product name");
		String name = scanner.next();
		float price = endpointInterface.getProductPrice(name);
		if(price==-1){
			System.out.println("product does not exist");
		}else{
			System.out.println("price is: "+price);
		}
	}
}
