package com.cg.learning.webservice;

import java.util.List;

import javax.jws.WebService;

import com.cg.learning.beans.Product;
import com.cg.learning.dao.IProductDao;
import com.cg.learning.dao.ProductDaoImpl;


@WebService(endpointInterface="com.cg.learning.webservice.IProductService")
public class ProductServiceImpl implements IProductService{

	IProductDao pdao = null;
	
	public ProductServiceImpl() {
		pdao = new ProductDaoImpl();
	}

	@Override
	public List<Product> getAllProducts() {
		return pdao.getAllProducts();
	}

	@Override
	public Product addProduct(Product product) {
		return pdao.addProduct(product);
	}

	
}
