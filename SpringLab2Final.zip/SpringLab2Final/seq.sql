create sequence mytrainee_seq
start with 1200
increment by 1;