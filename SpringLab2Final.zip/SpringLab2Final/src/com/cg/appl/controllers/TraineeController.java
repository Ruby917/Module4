package com.cg.appl.controllers;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.appl.entities.Traniee;
import com.cg.appl.exception.TraineeException;
import com.cg.appl.services.TraineeServices;

@Controller
public class TraineeController {
	private TraineeServices services;
	private List<String> domainList=null;
	private List<String> locations=null;
	@PostConstruct
	public void initialize(){
		domainList=new ArrayList<>();
		domainList.add("Java");
		domainList.add("DotNet");
		domainList.add("Databases");
		domainList.add("Analytics");
			
		locations=new ArrayList<>();
		locations.add("Pune");
		locations.add("Mumbai");
		locations.add("Bengluru");
		locations.add("Kolkata");
		locations.add("Delhi");
		
	}
	@Resource(name="traineeService")
	public void setTraineeServices(TraineeServices services){
		this.services=services;
	}
	@RequestMapping("/menu.do")
	public ModelAndView getMenuPag(){
		ModelAndView model=new ModelAndView("menu");		
		return model;
	}
	@RequestMapping("/auth.do")
	public ModelAndView getMenuPage(@RequestParam String uName,@RequestParam String password){		
		if(uName.equalsIgnoreCase("a")){
			if(password.equals("a")){
				ModelAndView model=new ModelAndView("menu");		
				return model;
			}
			else{
				ModelAndView model=new ModelAndView("error");		
				return model;
			}
		}else{
			ModelAndView model=new ModelAndView("error");		
			return model;
		}
	
	}
	@RequestMapping("/insertTrainee.do")
	public ModelAndView insertTrainee(){		
		ModelAndView model=new ModelAndView("insertTrainee");
		model.addObject("trainee",new Traniee());
		model.addObject("domains",domainList);
		model.addObject("locations", locations);
		return model;
	}
	@RequestMapping("/submitInsertDetails.do")
	public ModelAndView submitInsertDetails(@ModelAttribute @Valid Traniee trainee,BindingResult result){
		ModelAndView model=new ModelAndView();
		if(result.hasErrors()){
			System.out.println(result.getAllErrors());
			model.addObject("trainee",new Traniee());
			model.addObject("domains",domainList);
			model.addObject("locations", locations);
			model.setViewName("success");
			return model;
		}
	
		try {
			Traniee train=services.insertNewTrainee(trainee);
			
			model.addObject("trainee",train);
			model.setViewName("succes");		
			
		} catch (TraineeException e) {
					model.setViewName("error");
					model.addObject("errMsg","Record Insertion failed .. "+e.getMessage());
		} 
	
		return model;
	}

	@RequestMapping("/listAllTrainees.do")
	public ModelAndView listAllTrainees(){
		ModelAndView model=null;
		try {
			List<Traniee> trainees=services.getAllTrainees();
			model = new ModelAndView("listAllTrainees");
			model.addObject("list",trainees);
		} catch (TraineeException e) {
			model = new ModelAndView("error");
			model.addObject("errorMsg",e.getMessage());
		}
		return model;

	}	
	
	@RequestMapping("/enterTraineeNo.do")
	public ModelAndView enterTraineeNo(){		
		ModelAndView model=new ModelAndView("enterTraineeNo");		
		return model;
	}
	@RequestMapping("/getTraineeDetails.do")
	public ModelAndView getTraineeDetails(@RequestParam int traineeId){
		ModelAndView model=null;
		try {
			Traniee traniee=services.getTraineeDetails(traineeId);
			model = new ModelAndView("traineeDetails");
			model.addObject("traniee",traniee);
		} catch (TraineeException e) {
			model = new ModelAndView("error");
			model.addObject("errorMsg",e.getMessage());
		}
		return model;
	}

@RequestMapping("/getDeleteTraineeID.do")
public ModelAndView getDeleteTraineeID(){
	ModelAndView model=new ModelAndView("getDeleteTraineeID");		
	return model;
	
}
@RequestMapping("/deleteTrainee.do")
public ModelAndView deleteTrainee(@RequestParam int  tid){
	ModelAndView model=null;
	try {
		System.out.println(tid);
		Traniee tr=services.deleteRecord(tid);
		
		model = new ModelAndView("deleted");
		model.addObject("tr",tr);
		
	} catch (TraineeException e) {
		model = new ModelAndView("error");
		model.addObject("errorMsg",e.getMessage());
	}
	return model;
}

@RequestMapping("/getModifyTrainee.do")
public ModelAndView getModifyTraineeID(){
	ModelAndView model=new ModelAndView("getModifyTrainee");		
	return model;
}
@RequestMapping("/modifyTrainee.do")
public ModelAndView modifyTrainee(@RequestParam int utid){
	ModelAndView model=null;
	try {
		System.out.println(utid);
		Traniee tr=services.getTraineeDetails(utid);
		System.out.println(tr);
		model = new ModelAndView("getModifyValues");
		model.addObject("tr",tr);
		model.addObject("trainee",new Traniee());
		model.addObject("domains",domainList);
		model.addObject("locations", locations);
		
	} catch (TraineeException e) {
		model = new ModelAndView("error");
		model.addObject("errorMsg",e.getMessage());
	}
	return model;
}

@RequestMapping("/updateDetails.do")
public ModelAndView updateToDB(@ModelAttribute Traniee trainee){
	ModelAndView model=null;
	try {
		System.out.println("in updateToDB() "+trainee);
		Traniee uptr=services.updateTrainee(trainee);
		System.out.println(uptr);
		model=new ModelAndView("success");
		return model;
	} catch (TraineeException e) {
		model=new ModelAndView("error");
		return model;}
}

}

	

