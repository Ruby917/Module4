package com.cg.appl.daos;

import java.util.List;

import com.cg.appl.entities.Traniee;
import com.cg.appl.exception.TraineeException;

public interface TraineeDao {
Traniee getTraineeDetails(int traineeId)throws TraineeException;
List<Traniee> getAllTrainees()throws TraineeException;
Traniee insertNewTrainee(Traniee trainee)throws TraineeException;
Traniee deleteRecord(int traineeId)throws TraineeException;
Traniee updateTrainee(Traniee trainee)throws TraineeException;
}
