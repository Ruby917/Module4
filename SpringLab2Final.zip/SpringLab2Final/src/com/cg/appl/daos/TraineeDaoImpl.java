package com.cg.appl.daos;

import java.util.List;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;
import javax.persistence.RollbackException;

import org.springframework.stereotype.Repository;

import com.cg.appl.entities.Traniee;
import com.cg.appl.exception.TraineeException;
@Repository("traineeDao")
public class TraineeDaoImpl implements TraineeDao {
private EntityManagerFactory factory; 

	@Resource(name="entityMFactory")
public void setEntityMFactory(EntityManagerFactory factory){
	this.factory=factory;
}
	@Override
	public Traniee getTraineeDetails(int traineeId) throws TraineeException {
		EntityManager manager=factory.createEntityManager();
		Traniee trainee=manager.find(Traniee.class,traineeId);
		return trainee;
	}
	@Override
	public List<Traniee> getAllTrainees() throws TraineeException {
		String selectQry="select t from Traniee t";
		EntityManager manager=factory.createEntityManager();
		Query qry=manager.createQuery(selectQry,Traniee.class);
		return qry.getResultList();
	}
	@Override
	public Traniee insertNewTrainee(Traniee trainee) throws TraineeException {
		EntityManager manager=factory.createEntityManager();
		try {
			manager.getTransaction().begin();
			manager.persist(trainee);
			manager.getTransaction().commit();
		} catch (RollbackException e) {
			throw new TraineeException("Violated Column Size",e);
		}
		
		return trainee;
	}
	@Override
	public Traniee deleteRecord(int traineeId) throws TraineeException {
		EntityManager manager=factory.createEntityManager();
		try {
			Traniee trainee=manager.find(Traniee.class,traineeId);
			manager.getTransaction().begin();
			manager.remove(trainee);
			manager.getTransaction().commit();
			return trainee;
		} catch (RollbackException e) {
			throw new TraineeException("Invalid Trainee-ID",e);
		}
	}
	@Override
	public Traniee updateTrainee(Traniee trainee) throws TraineeException {
		EntityManager manager=factory.createEntityManager();
		try {
			manager.getTransaction().begin();
			manager.merge(trainee);
			manager.getTransaction().commit();
			
		} catch (RollbackException e) {
			throw new TraineeException("Cannot Update",e);
		}
		return trainee;
	}
	}

