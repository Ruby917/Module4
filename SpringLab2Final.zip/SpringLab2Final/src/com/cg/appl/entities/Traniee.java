package com.cg.appl.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity(name="Traniee")
@Table(name="traniee")
@SequenceGenerator(name="trainee_generate", sequenceName="mytrainee_seq", allocationSize=1,initialValue=1200)
public class Traniee {
private int tranieeId;
private String tranieeName;
private String traineeDomain;
private String traineeLocation;
public Traniee() {
	super();
}
@Id
@GeneratedValue(generator="trainee_generate",strategy=GenerationType.SEQUENCE)
public int getTranieeId() {
	return tranieeId;
}
public void setTranieeId(int tranieeId) {
	this.tranieeId = tranieeId;
}
public String getTranieeName() {
	return tranieeName;
}
public void setTranieeName(String tranieeName) {
	this.tranieeName = tranieeName;
}
public String getTraineeDomain() {
	return traineeDomain;
}
public void setTraineeDomain(String traineeDomain) {
	this.traineeDomain = traineeDomain;
}
public String getTraineeLocation() {
	return traineeLocation;
}
public void setTraineeLocation(String traineeLocation) {
	this.traineeLocation = traineeLocation;
}
@Override
public String toString() {
	return "Traniee [tranieeId=" + tranieeId + ", tranieeName=" + tranieeName
			+ ", tranieeDomain=" + traineeDomain + ", trannieeLocation="
			+ traineeLocation + "]";
}



}
