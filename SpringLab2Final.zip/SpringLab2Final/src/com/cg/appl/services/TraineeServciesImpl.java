package com.cg.appl.services;

import java.util.List;

import javax.annotation.Resource;
import javax.transaction.Transactional;

import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.cg.appl.daos.TraineeDao;
import com.cg.appl.entities.Traniee;
import com.cg.appl.exception.TraineeException;
@Service("traineeService")
@EnableTransactionManagement
public class TraineeServciesImpl implements TraineeServices {
	private TraineeDao dao;
	@Resource(name="traineeDao")
	public void setTraineeDao(TraineeDao dao){
		this.dao=dao;
	}

	@Override
	public Traniee getTraineeDetails(int traineeId) throws TraineeException {
		return dao.getTraineeDetails(traineeId);
	}

	@Override
	public List<Traniee> getAllTrainees() throws TraineeException {
		return dao.getAllTrainees();
	}
	
	
@Transactional
	@Override
	public Traniee insertNewTrainee(Traniee trainee) throws TraineeException {
		
		return dao.insertNewTrainee(trainee);
	}

@Override
public Traniee deleteRecord(int traineeId) throws TraineeException {

	return dao.deleteRecord(traineeId);
}

@Override
public Traniee updateTrainee(Traniee trainee) throws TraineeException {

	return dao.updateTrainee(trainee);
}

}
