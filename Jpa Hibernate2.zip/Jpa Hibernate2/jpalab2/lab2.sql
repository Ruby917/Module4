create table book1(authorid number(10),isbn number(10),title varchar2(20),price float(10));

insert into book1 values(12,10001,'3mistakes',250.0);
select * from book1;
select * from author;
