package com.cg.appl.services;

import java.util.List;

import com.cg.appl.Exceptions.AuthorException;
import com.cg.appl.entities.Author;
import com.cg.appl.entities.Book;



public interface AuthorService {
	Author getAutDetailsSafe(int authorid) throws AuthorException;

	List<Author> getAutList() throws AuthorException;
	List<Book> getbookList() throws AuthorException;
	Book getbookList(int authorid) throws AuthorException;
	
	Book admitNewbook(Book book) throws AuthorException;
	
	
	List<Book> getBookOnPrice(float from,float to) throws AuthorException;
	//Book getbookList(int authorid) throws AuthorException;
	
	
}
