package com.cg.appl.services;

import java.util.List;










import com.cg.appl.Exceptions.AuthorException;
import com.cg.appl.daos.AuthorDao;
import com.cg.appl.daos.AuthorDaoImpl;
import com.cg.appl.entities.Author;
import com.cg.appl.entities.Book;




public class AuthorServiceImpl implements AuthorService{
AuthorDao dao;


	public AuthorServiceImpl() {
	super();
	try {
		dao=new AuthorDaoImpl();
	} catch (AuthorException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}

	@Override
	public Author getAutDetailsSafe(int authorid) throws AuthorException {
		
		return dao.getAutDetailsSafe(authorid);
	}

	@Override
	public List<Author> getAutList() throws AuthorException {
		// TODO Auto-generated method stub
		return dao.getAutList();
	}

	
	@Override
	public Book getbookList(int authorid) throws AuthorException {
		
		return dao.getbookList(authorid);
	}

	@Override
	public Book admitNewbook(Book book) throws AuthorException {
		
		return dao.admitNewbook(book);
	}

	@Override
	public List<Book> getBookOnPrice(float from, float to)
			throws AuthorException {
		
		return dao.getBookOnPrice(from, to);
	}

	@Override
	public List<Book> getbookList() throws AuthorException {
		
		return dao.getbookList();
	}
	
}
