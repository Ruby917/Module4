package com.cg.appl.tests;

import java.util.List;

import com.cg.appl.Exceptions.AuthorException;
import com.cg.appl.entities.Author;
import com.cg.appl.entities.Book;

import com.cg.appl.services.AuthorService;
import com.cg.appl.services.AuthorServiceImpl;



public class TestEmp {

	public static void main(String[] args) throws AuthorException {
		try {
			
AuthorService services=new AuthorServiceImpl();
///////////////////////////AUTHOR DETAILS FOR PARTICULAR AUTHORID///////////////////////////////////////
			/*Author aut=services.getAutDetailsSafe(authorid);
			System.out.println();*/
//////////////////////////////////////////////ASSOCIATION////////////////////////////////////////	
/*Book book=services.getbookList(12);
for(Author aut :book.getAut()){
	  System.out.println(aut);
}
System.out.println(book);
			*/
//////////////////////SHOWING AUTHORLIST///////////////////////////////////////////////////////////////
			
			/* for (Author aut:services.getAutList()){
			  System.out.println(aut); }*/
/////////////////////////////INSERTING AUTHOR DETAILS//////////////////////////////////////////////////////
/*			
Author aut=new Author();
aut.setAuthorid(12);
aut.setFirstname("nivi");
aut.setMiddlename("u");
aut.setLastname("singh");
aut.setPhoneno(263480);
services.admitNewAut(aut);
Author aut1=new Author();
aut1.setAuthorid(14);
aut1.setFirstname("sumu");
aut1.setMiddlename("a");
aut1.setLastname("parte");
aut1.setPhoneno(262737);
services.admitNewAut(aut1);
Author aut2=new Author();
aut2.setAuthorid(16);
aut2.setFirstname("neha");
aut2.setMiddlename("p");
aut2.setLastname("pansare");
aut2.setPhoneno(2634802);
services.admitNewAut(aut2);



System.out.println(services.getAutDetailsSafe(12));
System.out.println(services.getAutDetailsSafe(14));
System.out.println(services.getAutDetailsSafe(16));
*//*
//////////////////////////////INSERTING BOOK DETAILS/////////////////////////////////////////////
		Book book1=new Book();
		book1.setAuthorid(18);
		book1.setIsbn(10002);
		book1.setTitle("revolution");
		book1.setPrice((float) 300.0);
		services.admitNewbook(book1);
		System.out.println(services.getbookList(18));*/
		/*for (Book book2:services.getbookList()){
			  System.out.println(book2);
		}*/
////////////////////////////////FIND BBOKDETAILS IN RANGE()///////////////////////////////////////////
		
		List<Book> bookList=services.getBookOnPrice(100, 270);
		for(Book book3:bookList){
		System.out.println(book3);
		}
//////////////////////////UPDATING NAME////////////////////////////////////////////////////////////		
			 /* services.updatename(16, "niki");
			  System.out.println(services.getAutDetailsSafe(16));*/
			

////////////////////////////INSERRTING AUTHORDETAILS/////////////////////////////////////////////////			
/*Author aut=new Author();
			
			  
			  aut.setAuthorid(126);
			  aut.setFirstname("nivid");
			  aut.setMiddlename("us");
			  aut.setLastname("singhh");
			  aut.setPhoneno(2634800);
			  services.updateAut(aut);
			  System.out.println(services.getAutDetailsSafe(126));*/
			/*services.deleteAut(16);
			System.out.println(services.getAutDetailsSafe(16));*/

		} catch (AuthorException e) {

			e.printStackTrace();
		}

	}

}
