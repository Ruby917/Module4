package com.cg.appl.entities;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;


@Entity(name="book")
@Table(name="book1")
@NamedQueries({
	@NamedQuery(name="qryRange",query="select b from book as b where price between :from and :to")
})
public class Book {
	private int authorid;
	private int isbn;
	private String title;
	private Float price;
	private List<Author> aut;
	
	
	
	
	@OneToMany(mappedBy="book") 
	public List<Author> getAut() {
		return aut;
	}
	public void setAut(List<Author> aut) {
		this.aut = aut;
	}
	@Id
	public int getAuthorid() {
		return authorid;
	}
	public void setAuthorid(int authorid) {
		this.authorid = authorid;
	}
	
	public int getIsbn() {
		return isbn;
	}
	public void setIsbn(int isbn) {
		this.isbn = isbn;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public Float getPrice() {
		return price;
	}
	public void setPrice(Float price) {
		this.price = price;
	}
	@Override
	public String toString() {
		return "Book [isbn=" + isbn + ", title=" + title + ", price=" + price
				+ "]";
	}
	
	
	

}
