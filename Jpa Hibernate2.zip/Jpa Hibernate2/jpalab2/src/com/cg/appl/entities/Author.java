package com.cg.appl.entities;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
@Entity(name="author")
@Table(name="author")
public class Author implements Serializable{
	
	private static final long serialVersionUID = 1L;
	private int authorid;
	private String firstname;
	private String middlename;
	private String lastname;
	private Book book;
	//private int phoneno;
	
	@Id
	public int getAuthorid() {         //authorid
		return authorid;
	}
	public void setAuthorid(int authorid) {
		this.authorid = authorid;
	}
	public String getFirstname() {         //firstname
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getMiddlename() {          //middlename
		return middlename;
	}
	public void setMiddlename(String middlename) {
		this.middlename = middlename;
	}
	public String getLastname() {                  //lastname
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	
	
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="AUTHORID")
	public Book getBook() {
		return book;
	}
	public void setBook(Book book) {
		this.book = book;
	}
	@Override
	public String toString() {
		return "Author [authorid=" + authorid + ", firstname=" + firstname
				+ ", middlename=" + middlename + ", lastname=" + lastname
				+ ", book=" + book + "]";
	}
	
	
	

}
