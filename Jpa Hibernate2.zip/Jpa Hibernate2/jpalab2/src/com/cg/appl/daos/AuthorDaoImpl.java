package com.cg.appl.daos;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.RollbackException;




import javax.persistence.TypedQuery;

import com.cg.appl.Exceptions.AuthorException;
import com.cg.appl.Util.EntityManageUtil;
import com.cg.appl.entities.Author;
import com.cg.appl.entities.Book;



public class AuthorDaoImpl implements AuthorDao {
	private EntityManageUtil util;
	private EntityManager manager;

	public AuthorDaoImpl() throws AuthorException {
		util = new EntityManageUtil();
		manager = util.getManager();
	}

	private Author  getAutDetails(int authorid) throws AuthorException {
		Author dept = manager.find(Author.class, authorid); // find method
																	// gives
		// persistent object and is only called in dao class and this is not
		// given to client side
		if (dept == null) {
			throw new AuthorException("wrong deptno");
		}

		return dept;
	}

	@Override
	public Author getAutDetailsSafe(int authorid) throws AuthorException {
		Author dept = manager.find(Author.class, authorid); // find method
																	// gives
		// persistent object and is only called in dao class and this is not
		// given to client side
		if (dept == null) {
			throw new AuthorException("wrong deptno");
		}
		manager.detach(dept);
		return dept;

	}

	@Override
	public List<Author> getAutList() throws AuthorException {
		try {
			Query qry = manager.createQuery("select  au from author as au"); // write
																			// class
																			// name
																			// and
																			// if
																			// ur
																			// giving
																			// entity
																			// name
																			// specify
																			// entity
																			// name
																			// and
																			// not
																			// classname
			List<Author> deptList = qry.getResultList();
			// for(Employee emp:empList){
			// System.out.println(emp);

			return deptList;
		} catch (Exception e) {
			throw new AuthorException("improper fabrication", e);

		}
	}

	

	@Override
	public Book getbookList(int authorid) throws AuthorException {
		Book book = manager.find(Book.class, authorid); // find method
		// gives
// persistent object and is only called in dao class and this is not
// given to client side
if (book == null) {
throw new AuthorException("wrong isbn");
}

return book;

		
	}


	@Override
	public Book admitNewbook(Book book) throws AuthorException {
		try {
			manager.getTransaction().begin();
			manager.persist(book); // persist() makes object persistent so that
									// it stays on drive and find() finds it
									// automatically thereby saving time
			manager.getTransaction().commit();
		} catch (RollbackException e) {
			throw new AuthorException("unique constraint violated", e);

		}
		return book;
		
	}

	@Override
	public List<Book> getBookOnPrice(float from, float to)
			throws AuthorException {
		TypedQuery<Book> qry=manager.createNamedQuery("qryRange", Book.class);
		qry.setParameter("from", from);
		
		qry.setParameter("to", to);
		return qry.getResultList();
		
	}
	@Override
	public List<Book> getbookList() throws AuthorException {
		try {
			Query qry = manager.createQuery("select  bo from book as bo"); // write
																			// class
																			// name
																			// and
																			// if
																			// ur
																			// giving
																			// entity
																			// name
																			// specify
																			// entity
																			// name
																			// and
																			// not
																			// classname
			List<Book> bookList = qry.getResultList();
			// for(Employee emp:empList){
			// System.out.println(emp);

			return bookList;
		} catch (Exception e) {
			throw new AuthorException("improper fabrication", e);

		}
		
	}

	@Override
	protected void finalize() throws Throwable {
		util.closeFactory();
		super.finalize();
	}

	

	
	
	

	


	

}
