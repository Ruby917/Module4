package com.cg.appl.daos;

import java.util.List;

import com.cg.appl.Exceptions.AuthorException;

import com.cg.appl.entities.Author;
import com.cg.appl.entities.Book;




public interface AuthorDao {

	Author getAutDetailsSafe(int authorid) throws AuthorException;

	List<Author> getAutList() throws AuthorException;
	List<Book> getbookList() throws AuthorException;

	Book admitNewbook(Book book) throws AuthorException;

	//boolean updatename(int authorid, String newname) throws AuthorException;

	//boolean updateAut(Author aut) throws AuthorException;

	//boolean deleteAut(int authorid) throws AuthorException;
	List<Book> getBookOnPrice(float from,float to) throws AuthorException;
	Book getbookList(int authorid) throws AuthorException;
}
