package com.cg.empdirectory.service;

import java.util.List;

import com.cg.empdirectory.dto.Employee;
import com.cg.empdirectory.exception.EmployeeException;

public interface EmployeeService {
	Employee addEmp(Employee emp) throws EmployeeException;
	List<Employee> getAllEmp() throws EmployeeException;
}
