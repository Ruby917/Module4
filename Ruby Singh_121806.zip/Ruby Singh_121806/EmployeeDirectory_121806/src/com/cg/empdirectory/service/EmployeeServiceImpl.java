package com.cg.empdirectory.service;

import java.util.List;

import javax.annotation.Resource;
import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.cg.empdirectory.dao.EmployeeDao;
import com.cg.empdirectory.dto.Employee;
import com.cg.empdirectory.exception.EmployeeException;
		
		/**
		 * Author		:	Ruby Singh
		 * Class Name	:	EmployeeServiceImpl
		 * Package		:	com.cg.empdirectory.service
		 * Date			:	31-Mar-2017
		 */

@Transactional
@Service("empService")
public class EmployeeServiceImpl implements EmployeeService{

	private EmployeeDao empDao;
	
	//---------------- 1. Authowiring Done ---------------
		/**************************************************************
		 - Method Name		:	setEmpDao()
		 - Input Parameters	:	
		 - Return Type		:	
		 - Throws			:   EmployeeException
		 - Author			:	Emp-ID: 121806
		 - Creation Date	:	31/03/2017
		 - Description		:	autowiring of dao class
		 *************************************************************/	
	@Resource(name="empDao")
	public void setEmpDao(EmployeeDao empDao){
		this.empDao = empDao;
	}
	
	
	//---------------- 2. Add employee Service method---------------
			/**************************************************************
			 - Method Name		:	addEmp()
			 - Input Parameters	:	Employee
			 - Return Type		:	Employee
			 - Throws			:   EmployeeException
			 - Author			:	Emp-ID: 121806
			 - Creation Date	:	31/03/2017
			 - Description		:	New employee's detail stored 
			 *************************************************************/	
	@Override
	public Employee addEmp(Employee emp) throws EmployeeException {
		return empDao.addEmp(emp);
	}
	//---------------- 3. Show All Employee Service method---------------
			/**************************************************************
			 - Method Name		:	getAllEmp()
			 - Input Parameters	:	Employee
			 - Return Type		:	List
			 - Throws			:   EmployeeException
			 - Author			:	Emp-ID: 121806
			 - Creation Date	:	31/03/2017
			 - Description		:	Show details of all employees
			 *************************************************************/	
	@Override
	public List<Employee> getAllEmp() throws EmployeeException {
		return empDao.getAllEmp();
	}	
	
}
