package com.cg.empdirectory.dto;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.PersistenceContext;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;

/**
 * Author		:	Ruby Singh
 * Class Name	:	Employee
 * Package		:	com.cg.empdirectory.dto
 * Date			:	31-Mar-2017
 */

@Entity(name = "EMP") // ALIES OF CLASS NAME
@Table(name = "EMPLOYEE") //TABLE NAME

@NamedQueries({
	@NamedQuery(name="getEmpList", query="select e from EMP e")
})

@SequenceGenerator(name="emp_seq", sequenceName="HIBERNATE_SEQUENCE" ,allocationSize=1, initialValue=1001)
  
public class Employee implements Serializable{

	private static final long serialVersionUID = 1L;

	//Properties of Employee
	private int emp_code;
	private String emp_name;
	private String emp_gender;
	private String design_name;
	private String emp_email;
	private String emp_phone;
	
	//Setter and getter of Properties of employee
	
	@Id
	@Column(name="EMPLOYEE_CODE")
	@GeneratedValue(generator="emp_seq", strategy=GenerationType.SEQUENCE)
	public int getEmp_code() {
		return emp_code;
	}
	public void setEmp_code(int emp_code) {
		this.emp_code = emp_code;
	}
	
	@Column(name="EMPLOYEE_NAME")
	@NotEmpty(message="Name is Required")
	@Size(min=1,max=40,message="Name must be of size less than 40 characters long")
	public String getEmp_name() {
		return emp_name;
	}
	public void setEmp_name(String emp_name) {
		this.emp_name = emp_name;
	}
	
	@Column(name="EMPLOYEE_GENDER")
	@NotEmpty(message="Please Enter your Gender")
	public String getEmp_gender() {
		return emp_gender;
	}
	public void setEmp_gender(String emp_gender) {
		this.emp_gender = emp_gender;
	}
	
	@Column(name="DESIGNATION_NAME")
	@NotEmpty(message="Please select your Designation")
	public String getDesign_name() {
		return design_name;
	}
	public void setDesign_name(String design_name) {
		this.design_name = design_name;
	}
	
	@Column(name="EMPLOYEE_EMAIL")
	@NotEmpty(message="Please Enter your Email Id")
	@Email(message="Please Enter Email Id in correct format")
	public String getEmp_email() {
		return emp_email;
	}
	public void setEmp_email(String emp_email) {
		this.emp_email = emp_email;
	}
	
	@Column(name="EMPLOYEE_PHONE")
	@Size(min=10,max=10,message="Phone Number should be of 10 digit long")
	public String getEmp_phone() {
		return emp_phone;
	}
	public void setEmp_phone(String emp_phone) {
		this.emp_phone = emp_phone;
	}
	
	//toString method of employee properties
	
	@Override
	public String toString() {
		return "EmployeeDto [emp_code=" + emp_code + ", emp_name=" + emp_name
				+ ", emp_gender=" + emp_gender + ", design_name=" + design_name
				+ ", emp_email=" + emp_email + ", emp_phone=" + emp_phone + "]";
	}
}
