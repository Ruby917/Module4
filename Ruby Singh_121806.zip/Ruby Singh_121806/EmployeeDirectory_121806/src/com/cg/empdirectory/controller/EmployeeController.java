package com.cg.empdirectory.controller;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cg.empdirectory.dto.Employee;
import com.cg.empdirectory.exception.EmployeeException;
import com.cg.empdirectory.service.EmployeeService;

		/**
		 * Author		:	Ruby Singh
		 * Class Name	:	EmployeeController
		 * Package		:	com.cg.empdirectory.controller
		 * Date			:	31-Mar-2017
		 */

@Controller
public class EmployeeController {
	
    private EmployeeService eService;
    private List<String> desigName;
	
	  //---------------- 1. List of Desinations ---------------
		/**************************************************************
		 - Method Name		:	initialize()
		 - Input Parameters	:	
		 - Return Type		:	
		 - Throws			:   EmployeeException
		 - Author			:	Emp-ID: 121806
		 - Creation Date	:	31/03/2017
		 - Description		:	Stores list of designations
		 *************************************************************/	
    @PostConstruct
	public void initialize() throws EmployeeException{
    	desigName = new ArrayList<>();
    	desigName.add("Software Engineer");
    	desigName.add("Senior Software Engineer");
    	desigName.add("Team Lead");
    	desigName.add("Manager");
	}
    
    
    
       //---------------- 2. Authowiring Done ---------------
  		/**************************************************************
  		 - Method Name		:	setEmpService()
  		 - Input Parameters	:	
  		 - Return Type		:	
  		 - Throws			:   EmployeeException
  		 - Author			:	Emp-ID: 121806
  		 - Creation Date	:	31/03/2017
  		 - Description		:	autowiring of service class
  		 *************************************************************/	
	@Resource(name="empService")
	public void setEmpService(EmployeeService eService){
		this.eService= eService;
	}
	
	
	
	 //---------------- 3. Show Home Page ---------------
		/**************************************************************
		 - Method Name		:	getWelcomePage()
		 - Input Parameters	:	
		 - Return Type		:	ModelAndView
		 - Throws			:   EmployeeException
		 - Author			:	Emp-ID: 121806
		 - Creation Date	:	31/03/2017
		 - Description		:	home page is displayed
		 *************************************************************/	
	@RequestMapping("home")
	public ModelAndView getWelcomePage(){
		ModelAndView model = new ModelAndView("home");
		return model;
	}
	
	
	 //---------------- 4. Show Employee Form ---------------
		/**************************************************************
		 - Method Name		:	addEmpForm()
		 - Input Parameters	:	
		 - Return Type		:	ModelAndView
		 - Throws			:   EmployeeException
		 - Author			:	Emp-ID: 121806
		 - Creation Date	:	31/03/2017
		 - Description		:	employee form is displayed
		 *************************************************************/	
	@RequestMapping("addEmpForm")
	public ModelAndView addEmpForm(){
		ModelAndView model = new ModelAndView("addEmployee");
		model.addObject("empDetails", new Employee());
		model.addObject("desigList", desigName);
		return model;
	}
	
	
	 //---------------- 5. Add Employee Details ---------------
		/**************************************************************
		 - Method Name		:	successAdd()
		 - Input Parameters	:	Employee,BindingResult
		 - Return Type		:	ModelAndView
		 - Throws			:   EmployeeException
		 - Author			:	Emp-ID: 121806
		 - Creation Date	:	31/03/2017
		 - Description		:	New employee's detail stored 
		 *************************************************************/	
	@RequestMapping("addEmp")
	public ModelAndView successAdd(@ModelAttribute("empDetails") @Valid Employee emp,BindingResult result){
		ModelAndView model = new ModelAndView();
		if(result.hasErrors()){
			model = new ModelAndView("addEmployee");
			model.addObject("empDetails", emp);
			model.addObject("desigList", desigName);
			return model;
		}
		try {
			Employee empres = eService.addEmp(emp);
			model.setViewName("success");
			model.addObject("empDetails", empres);
		} catch (EmployeeException e) {
			model.setViewName("error");
			model.addObject("msg", "Record Insertion Failed:"+e.getMessage());
		}
		return model;
	}
	
	
	 //---------------- 6. Show Employee Details ---------------
		/**************************************************************
		 - Method Name		:	listAllEmp()
		 - Input Parameters	:	
		 - Return Type		:	ModelAndView
		 - Throws			:   EmployeeException
		 - Author			:	Emp-ID: 121806
		 - Creation Date	:	31/03/2017
		 - Description		:	Show details of all Employees
		 *************************************************************/	
	@RequestMapping("showAllEmp")
	public ModelAndView listAllEmp(){
		ModelAndView model = null;
		try {
			List<Employee> emps = eService.getAllEmp();
			model = new ModelAndView("showAllEmp");
			model.addObject("empDetails", emps);
		} catch (EmployeeException e) {
			model = new ModelAndView("error");
			model.addObject("msg", e.getMessage());
		}
		return model;
	}

}
