package com.cg.empdirectory.exception;

/**
 * Author		:	Ruby Singh
 * Class Name	:	EmployeeException
 * Package		:	com.cg.empdirectory.exception
 * Date			:	31-Mar-2017
 */

public class EmployeeException extends Exception {

	private static final long serialVersionUID = 1L;

	//Abstract Methods of java.lang.Exception
	//******************************************************************************************
	public EmployeeException() {
		
	}

	public EmployeeException(String message) {
		super(message);
	}

	public EmployeeException(Throwable cause) {
		super(cause);
	}

	public EmployeeException(String message, Throwable cause) {
		super(message, cause);
	}

	public EmployeeException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}
	//******************************************************************************************

}
