package com.cg.empdirectory.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.RollbackException;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.empdirectory.dto.Employee;
import com.cg.empdirectory.exception.EmployeeException;

		/**
		 * Author		:	Ruby Singh
		 * Class Name	:	EmployeeDaoImpl
		 * Package		:	com.cg.empdirectory.dao
		 * Date			:	31-Mar-2017
		 */

@Repository("empDao")
public class EmployeeDaoImpl implements EmployeeDao{

	@PersistenceContext
	private EntityManager manager;

	
	//---------------- 1. Add Employee details ---------------
		/**************************************************************
		 - Method Name		:	addEmp()
		 - Input Parameters	:	Employee
		 - Return Type		:	Employee
		 - Throws			:   EmployeeException
		 - Author			:	Emp-ID: 121806
		 - Creation Date	:	31/03/2017
		 - Description		:	New employee's detail stored 
		 *************************************************************/	
	@Override
	public Employee addEmp(Employee emp) throws EmployeeException {
		try {
			manager.persist(emp);
			manager.flush();
		} catch (RollbackException rl) {
			throw new EmployeeException("Employee duplicated",rl);
		}
		return emp;
	}
	
	//---------------- 2. Show Employee details ---------------
			/**************************************************************
			 - Method Name		:	getAllEmp()
			 - Input Parameters	:	
			 - Return Type		:	List
			 - Throws			:   EmployeeException
			 - Author			:	Emp-ID: 121806
			 - Creation Date	:	31/03/2017
			 - Description		:	Show details of all Employees
			 *************************************************************/	
	@Override
	public List<Employee> getAllEmp() throws EmployeeException {
		List<Employee> emplist;
		try {
			TypedQuery<Employee> qry = manager.createNamedQuery("getEmpList",Employee.class);
			emplist = qry.getResultList();
		} catch (Exception e) {
			throw new EmployeeException("Improper query fabrication",e);
		}
		return emplist;
	}
	
	
}
