package com.cg.empdirectory.dao;

import java.util.List;

import com.cg.empdirectory.dto.Employee;
import com.cg.empdirectory.exception.EmployeeException;


public interface EmployeeDao {
	Employee addEmp(Employee emp) throws EmployeeException;
	List<Employee> getAllEmp() throws EmployeeException;
}
