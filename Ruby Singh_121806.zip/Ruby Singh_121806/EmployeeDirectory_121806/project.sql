drop table employee;

CREATE TABLE employee(employee_code NUMBER PRIMARY KEY, employee_name VARCHAR2(20), employee_gender VARCHAR(10), designation_name VARCHAR2(30), employee_email VARCHAR2(30), employee_phone NUMBER(10));

CREATE SEQUENCE hibernate_sequence
start with 1001
increment by 1;

commit

select * from employee;

truncate table employee;
drop Sequence hibernate_sequence;