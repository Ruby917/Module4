

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class SpringUtil {
	private ApplicationContext context;

	public SpringUtil() {
		context = new ClassPathXmlApplicationContext("employee.xml");
	}
	
	public ApplicationContext getSpringContext(){
		return context;
	}

}
