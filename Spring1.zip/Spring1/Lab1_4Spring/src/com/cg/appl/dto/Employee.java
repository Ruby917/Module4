package com.cg.appl.dto;


import java.io.Serializable;

public class Employee implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private int empId;
	private String empNm;
	private Float empSal;
	
	public Employee() {
	}
	
	public Employee(int empId, String empNm, Float empSal) {
		super();
		this.empId = empId;
		this.empNm = empNm;
		this.empSal = empSal;
	}
	
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpNm() {
		return empNm;
	}
	public void setEmpNm(String empNm) {
		this.empNm = empNm;
	}
	public Float getEmpSal() {
		return empSal;
	}
	public void setEmpSal(Float empSal) {
		this.empSal = empSal;
	}

	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empNm=" + empNm + ", empSal="
				+ empSal + "]";
	}
}
