package com.cg.appl.dao;

import java.util.List;

import com.cg.appl.dto.Employee;
import com.cg.appl.exceptions.EmployeeException;
import com.cg.appl.staticdb.Collection;

public class EmployeeDaoImpl implements EmployeeDao{
	
	List<Employee> employeeList = Collection.loadList();

	@Override
	public Employee getEmployeeDetails(int empId) throws EmployeeException {
		Employee emp = new Employee();
		for(Employee e:employeeList){
			if(e.getEmpId()==empId){
				return e;
			}
			
		}
		return emp;
	}
}













