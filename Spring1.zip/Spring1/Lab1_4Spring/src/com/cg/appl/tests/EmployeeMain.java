package com.cg.appl.tests;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;

import com.cg.appl.dto.Employee;
import com.cg.appl.exceptions.EmployeeException;
import com.cg.appl.service.IEmployeeService;
import com.cg.appl.util.SpringUtil;


public class EmployeeMain {
	public static void main(String[] args) {
		SpringUtil util = new SpringUtil();
		ApplicationContext ctx = util.getSpringContext();
		IEmployeeService service = ctx.getBean("empservice",IEmployeeService.class);
		
		System.out.println("Enter Employee Id:");
		Scanner sc = new Scanner(System.in);
		int eid = sc.nextInt();
		try {
			Employee e = service.getEmployeeDetails(eid);
			if(e.getEmpId()!=0){
				System.out.println("Employee Info : ");
				System.out.println("Employee Id : " +e.getEmpId());
				System.out.println("Employee Name : "+e.getEmpNm());
				System.out.println("Employee Salary : "+e.getEmpSal());
			}else{
				System.out.println("No employee data available");
			}
		} catch (EmployeeException e) {
			e.printStackTrace();
		}
		
	}

}
