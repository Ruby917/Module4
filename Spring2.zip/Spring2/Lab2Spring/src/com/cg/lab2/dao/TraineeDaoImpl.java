package com.cg.lab2.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.RollbackException;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.lab2.dto.Trainee;
import com.cg.lab2.exception.TraineeException;


@Repository("traineeDao")
public class TraineeDaoImpl implements TraineeDao{
	@PersistenceContext
	private EntityManager manager;

	@Override
	public Trainee getTraineeDetails(int trId) throws TraineeException {
		Trainee trainee = manager.find(Trainee.class, trId);
		return trainee;
	}

	@Override
	public List<Trainee> getAllTrainee() throws TraineeException {
		String qryStr = "select t from trainee t";
		TypedQuery<Trainee> qry = manager.createQuery(qryStr,Trainee.class);
		return qry.getResultList();
	}

	@Override
	public Trainee addTrainee(Trainee tr) throws TraineeException {
		try {
			manager.persist(tr);
			manager.flush();
		} catch (RollbackException rl) {
			throw new TraineeException("Trainee duplicated",rl);
		}
		return tr;
	}

	@Override
	public Boolean DeleteTrainee(int trId) throws TraineeException {
		try {
			Trainee tr = this.getTraineeDetails(trId);
			manager.remove(tr);
			return true;
		} catch (Exception e) {
			throw new TraineeException("failed trainee deletion",e);
			
		}
	}

	@Override
	public Trainee updateTrainee(Trainee tr) throws TraineeException {
		try {
			manager.merge(tr);
			manager.flush();
		} catch (RollbackException rl) {
			throw new TraineeException("Trainee duplicated",rl);
		}
		return tr;
	}



}



