package com.cg.lab2.service;

import java.util.List;

import javax.annotation.Resource;
import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.cg.lab2.dao.TraineeDao;
import com.cg.lab2.dto.Trainee;
import com.cg.lab2.exception.TraineeException;

@Transactional
@Service("traineeService")
public class TraineeServiceImpl implements TraineeService{

	private TraineeDao trDao;
	
	@Resource(name="traineeDao")
	public void setTraineeDao(TraineeDao trDao){
		this.trDao = trDao;
	}

	@Override
	public Trainee getTraineeDetails(int trId) throws TraineeException {
		return trDao.getTraineeDetails(trId);
	}

	@Override
	public List<Trainee> getAllTrainee() throws TraineeException {
		return trDao.getAllTrainee();
	}
	
	@Override
	public Trainee addTrainee(Trainee tr) throws TraineeException {
		return trDao.addTrainee(tr);
	}

	@Override
	public Boolean DeleteTrainee(int trId) throws TraineeException {
		return trDao.DeleteTrainee(trId);
	}

	@Override
	public Trainee updateTrainee(Trainee tr) throws TraineeException {
		return trDao.updateTrainee(tr);
	}

}

