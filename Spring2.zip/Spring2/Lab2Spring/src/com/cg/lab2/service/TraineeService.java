package com.cg.lab2.service;

import java.util.List;

import com.cg.lab2.dto.Trainee;
import com.cg.lab2.exception.TraineeException;

public interface TraineeService {
	Trainee getTraineeDetails(int trId) throws TraineeException;
	List<Trainee> getAllTrainee() throws TraineeException;
	Trainee addTrainee(Trainee tr) throws TraineeException;
	Boolean DeleteTrainee(int trId) throws TraineeException;
	Trainee updateTrainee(Trainee tr) throws TraineeException;
}
