var traineeModule = angular.module("traineemodule", []) // module method
														// //inside[] is name of
														// dependency files

traineeModule.controller("traineescontroller", function($scope) {

	$scope.trainees = [ {
		'traineeid' : '12',
		'traineename' : 'name',
		'traineedomain' : 'java',
		'traineeloacation' : 'mumbai'

	}, {
		'traineeid' : '14',
		'traineename' : 'name2',
		'traineedomain' : 'java',
		'traineeloacation' : 'mumbai'

	},

	{
		'traineeid' : '16',
		'traineename' : 'name3',
		'traineedomain' : 'java',
		'traineeloacation' : 'mumbai'

	}

	];
	
	        	

}

);

traineeModule.controller("traineecontroller",
		function($scope) {
	$scope.trainees={
			'traineename' :"name",
			'traineedomain' : "",
			'traineeloacation' : ""
	};
	$scope.domains=[
	        		'java','database','.net','oracle'];
	        	$scope.locations=[
	        	        		'pune','mumbai','goa','kolkata'];
	
	
}
);

