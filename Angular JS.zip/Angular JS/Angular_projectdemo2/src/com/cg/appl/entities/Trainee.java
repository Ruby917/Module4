package com.cg.appl.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity(name="trainee")
@Table(name="trainee")
public class Trainee {
private int traineeid;
private String traineename;
private String traineedomain;
private String traineelocation;
public Trainee(int traineeid, String traineename, String traineedomain,
		String traineelocation) {
	super();
	this.traineeid = traineeid;
	this.traineename = traineename;
	this.traineedomain = traineedomain;
	this.traineelocation = traineelocation;
}
public Trainee() {
	super();
}
@Id
public int getTraineeid() {
	return traineeid;
}
public void setTraineeid(int traineeid) {
	this.traineeid = traineeid;
}
public String getTraineename() {
	return traineename;
}
public void setTraineename(String traineename) {
	this.traineename = traineename;
}
public String getTraineedomain() {
	return traineedomain;
}
public void setTraineedomain(String traineedomain) {
	this.traineedomain = traineedomain;
}
@Column(name="traineeloacation")
public String getTraineelocation() {
	return traineelocation;
}
public void setTraineelocation(String traineelocation) {
	this.traineelocation = traineelocation;
}
@Override
public String toString() {
	return "Trainee [traineeid=" + traineeid + ", traineename=" + traineename
			+ ", traineedomain=" + traineedomain + ", traineelocation="
			+ traineelocation + "]";
}

















}
