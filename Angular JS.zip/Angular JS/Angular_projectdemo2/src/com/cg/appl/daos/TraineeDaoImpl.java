package com.cg.appl.daos;

import java.util.List;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;




import javax.persistence.Query;

import org.springframework.stereotype.Repository;


import com.cg.appl.entities.Trainee;
import com.cg.appl.exception.TraineeException;
@Repository("TraineeDao")
public class TraineeDaoImpl implements TraineeDao {
	private EntityManagerFactory factory;
	
@Resource(name="entityMFactory")
	public void setFactory(EntityManagerFactory factory) {
		this.factory = factory;
	}


	@Override
	public Trainee getTraineeDetails(int traineeid) throws TraineeException {
		EntityManager manager=factory.createEntityManager();
		Trainee trn = manager.find(Trainee.class, traineeid); // find method gives
		// persistent object and is only called in dao class and this is not given to client side
if (trn == null) {
throw new TraineeException("wrong trainee");
}

return trn;
		
	}


	@Override
	public List<Trainee> getAllTrainee() throws TraineeException {
		String qryStr="select t from trainee t";
		EntityManager manager=factory.createEntityManager();
		Query qry=manager.createQuery(qryStr, Trainee.class);
		return qry.getResultList();
	}


	@Override
	public Trainee admitNewTrn(Trainee trn) throws TraineeException {
		try {
			((EntityManager) factory).getTransaction().begin();
			((EntityManager) factory).persist(trn); // persist() makes object persistent so that
									// it stays on drive and find() finds it
									// automatically thereby saving time
			((EntityManager) factory).getTransaction().commit();
		} catch (Exception e) {
			
			e.printStackTrace();
			throw new TraineeException("unique constraint violated", e);
		}
		return trn;
	}

}
