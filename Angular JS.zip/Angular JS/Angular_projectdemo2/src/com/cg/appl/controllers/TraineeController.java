package com.cg.appl.controllers;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.appl.entities.Trainee;
import com.cg.appl.exception.TraineeException;
import com.cg.appl.services.TraineeService;

@Controller
public class TraineeController {
	private TraineeService services;
	
	
	
	@Resource(name="TraineeService")
public void setServices(TraineeService services) {
		this.services = services;
	}
	
	
	@RequestMapping("authenticate")
	public ModelAndView authenticate(@RequestParam String username,@RequestParam String password){
		System.out.println("in handlecontoller2");
		System.out.println("username");
		System.out.println("password");
		ModelAndView model=new ModelAndView();
		if(username.equals("a")&&(password.equals("a"))){
			model.setViewName("success");
			model.addObject("username",username);
		}else{
			model.addObject("message", "login unsuccessfel...login again");
			model.setViewName("login");
		}
		
		return model;
	
	}
	
	

@RequestMapping("/welcome.do")
	public ModelAndView getwelcomepage(){
		System.out.println("in handlecontoller1");
		ModelAndView model=new ModelAndView("welcome");
		return model;
		
	}
	

@RequestMapping("/enter.do")
	public ModelAndView entertraineeno(){
		System.out.println("in handlecontoller1");
		ModelAndView model=new ModelAndView("accept");
		return model;
		
	}

@RequestMapping("getdetail")
public ModelAndView getTraineeDetails(@RequestParam("traineeno") int traineeno){
	System.out.println("in handlecontoller2");
	System.out.println(traineeno);
	//System.out.println("password");
	ModelAndView model=null;
	/*if(username.equals("a")&&(password.equals("a"))){
		model.setViewName("success");
		model.addObject("username",username);
	}else{
		model.addObject("message", "login unsuccessfel...login again");
		model.setViewName("login");
	}*/
	
	try {
		Trainee trn=services.getTraineeDetails(traineeno);
		model=new ModelAndView("traineedetails");
		//model.addObject(trn);

		//model.addObject("message", "your traineeno is");
		model.addObject("message1", trn);
		
	} catch (TraineeException e) {
		model=new ModelAndView("error");
		e.printStackTrace();
	}
	
	return model;



}
@RequestMapping("/list.do")
public ModelAndView listtrainee(){
	System.out.println("in handlecontoller2");
	ModelAndView model=null;
	try {
		 model=new ModelAndView("list");
		List<Trainee>trns=services.getAllTrainee();
		
		model.addObject("trainees", trns);
	} catch (TraineeException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		model=new ModelAndView("error");
		e.printStackTrace();
	}
	
	return model;
	
}
/*
@RequestMapping("/add.do")
public ModelAndView admitnewtrn(){
	System.out.println("in handlecontoller3");
	ModelAndView model=null;
	try {
		 model=new ModelAndView("addtrn");
		Trainee trn=new Trainee(); 
			trn.setTraineeid(20);
			trn.setTraineename("chinnu");
			trn.setTraineedomain("java");
			  services.admitNewDept(emp);
			  System.out.println(services.getDeptDetailsSafe(15))
		//List<Trainee>trns=services.admitNewTrn(trn);
		
		model.addObject("trainees", trns);
	} catch (TraineeException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		model=new ModelAndView("error");
		e.printStackTrace();
	}
	
	return model;
	
}*/



}
