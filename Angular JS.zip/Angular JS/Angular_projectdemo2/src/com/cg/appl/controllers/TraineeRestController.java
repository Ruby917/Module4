package com.cg.appl.controllers;

import java.util.List;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.appl.entities.Trainee;
import com.cg.appl.exception.TraineeException;
import com.cg.appl.services.TraineeService;
//http://localhost:8085/com.cg.appl.controllers.TraineeRestController/trainees.do
@RestController
public class TraineeRestController {
	private TraineeService services;

	public TraineeService getServices() {
		return services;
	}

	public void setServices(TraineeService services) {
		this.services = services;
	}
	
	@RequestMapping(value="/trainees.do",method=RequestMethod.GET,headers="Accept=application/json")
	public List<Trainee> getTraineelist() throws TraineeException{
		return services.getAllTrainee();
		
	}
	
	

}
