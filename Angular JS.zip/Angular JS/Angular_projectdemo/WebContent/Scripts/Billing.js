var billModule=angular.module("billModule",[])         //module method //inside[] is name of dependency files

billModule.controller("billcontroller",
		function($scope){
	
	
			$scope.billitem={
			'qty':1,
			'cost':1,
			'discount' :0
			
	};
			$scope.calcbill=function(){
				return $scope.billitem.qty*$scope.billitem.cost;
			};
	
			$scope.calcdiscount=function(){
				return ($scope.billitem.discount===0?0: $scope.calcbill()/$scope.billitem.discount);
			};

$scope.calcnetbill=function(){
	return $scope.calcbill()-$scope.calcdiscount();
};

}

);