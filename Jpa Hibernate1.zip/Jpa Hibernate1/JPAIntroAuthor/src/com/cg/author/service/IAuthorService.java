package com.cg.author.service;

import java.util.List;

import com.cg.author.dto.Author;
import com.cg.author.exception.AuthorException;

public interface IAuthorService {
	Author addNewAuthor(Author auth) throws AuthorException;
	List<Author> displayAuthList() throws AuthorException;
	boolean upadteAuthor(Author auth) throws AuthorException;
	boolean deleteAuthor(int authId) throws AuthorException;
}
