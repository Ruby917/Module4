create table authors(authorid number(5) primary key, firstname varchar(10),middlename varchar(10),lastname varchar(10),phoneno number(10));
select * from authors;