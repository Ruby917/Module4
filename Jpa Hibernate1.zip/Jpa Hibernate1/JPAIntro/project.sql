CREATE TABLE greet
(messageid NUMBER(5) PRIMARY KEY,
message VARCHAR2(25));